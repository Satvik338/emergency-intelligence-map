import { useState, useCallback, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MapPin, Navigation, AlertTriangle, Ruler, Clock, Zap, ChevronDown, ChevronUp, X } from 'lucide-react';
import { incidents } from '../data/incidents';
import type { Incident, Coordinate } from '../types';

// Google Maps types declared in EmergencyMap.tsx

interface RouteResult {
  distance: string;
  distanceKm: number;
  duration: string;
  durationMinutes: number;
  path: { lat: number; lng: number }[];
  hazards: IncidentHazard[];
}

interface IncidentHazard {
  incident: Incident;
  distanceKm: number;
  segmentIndex: number;
}

interface EmergencyRouteHUDProps {
  map: any; // google.maps.Map
  onClose: () => void;
}

const PRESET_LOCATIONS = [
  { label: 'Delhi Command Center', lat: 28.6139, lng: 77.2090 },
  { label: 'Chennai Emergency HQ', lat: 13.0827, lng: 80.2707 },
  { label: 'Guwahati Relief Center', lat: 26.1445, lng: 91.7362 },
  { label: 'Mumbai Control Room', lat: 19.0760, lng: 72.8777 },
  { label: 'Kolkata Disaster Cell', lat: 22.5726, lng: 88.3639 },
  { label: 'Bangalore NDRF Base', lat: 12.9716, lng: 77.5946 },
];

export default function EmergencyRouteHUD({ map, onClose }: EmergencyRouteHUDProps) {
  const [origin, setOrigin] = useState('');
  const [destination, setDestination] = useState('');
  const [originCoords, setOriginCoords] = useState<Coordinate | null>(null);
  const [destinationCoords, setDestinationCoords] = useState<Coordinate | null>(null);
  const [routeResult, setRouteResult] = useState<RouteResult | null>(null);
  const [calculating, setCalculating] = useState(false);
  const [showPresets, setShowPresets] = useState<'origin' | 'dest' | null>(null);
  const [expanded, setExpanded] = useState(true);

  const routeLineRef = useRef<any>(null);
  const hazardMarkersRef = useRef<any[]>([]);
  const dangerPolylineRefs = useRef<any[]>([]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (routeLineRef.current) routeLineRef.current.setMap(null);
      hazardMarkersRef.current.forEach((m) => m.setMap(null));
      dangerPolylineRefs.current.forEach((p) => p.setMap(null));
    };
  }, []);

  const selectPreset = useCallback((preset: { label: string; lat: number; lng: number }, target: 'origin' | 'dest') => {
    if (target === 'origin') {
      setOrigin(preset.label);
      setOriginCoords({ lat: preset.lat, lng: preset.lng });
    } else {
      setDestination(preset.label);
      setDestinationCoords({ lat: preset.lat, lng: preset.lng });
    }
    setShowPresets(null);
  }, []);

  // Haversine formula for straight-line distance
  const haversineDistance = (lat1: number, lng1: number, lat2: number, lng2: number): number => {
    const R = 6371;
    const dLat = ((lat2 - lat1) * Math.PI) / 180;
    const dLng = ((lng2 - lng1) * Math.PI) / 180;
    const a = Math.sin(dLat / 2) ** 2 + Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
    return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  };

  // Find nearby hazards along a path
  const findHazards = (path: { lat: number; lng: number }[]): IncidentHazard[] => {
    const hazards: IncidentHazard[] = [];
    const PROXIMITY_KM = 10;
    for (const incident of incidents) {
      if (!incident.isActive) continue;
      let minDist = Infinity;
      let segIdx = 0;
      for (let i = 0; i < path.length; i += Math.max(1, Math.floor(path.length / 50))) {
        const dist = haversineDistance(incident.coordinates.lat, incident.coordinates.lng, path[i].lat, path[i].lng);
        if (dist < minDist) { minDist = dist; segIdx = i; }
      }
      if (minDist <= PROXIMITY_KM && !hazards.find((h) => h.incident.id === incident.id)) {
        hazards.push({ incident, distanceKm: Math.round(minDist * 10) / 10, segmentIndex: segIdx });
      }
    }
    return hazards;
  };

  // Draw route on map with danger segments highlighted
  const drawRoute = (path: { lat: number; lng: number }[], hazards: IncidentHazard[]) => {
    const fullPath = path.map((p) => new window.google.maps.LatLng(p.lat, p.lng));

    const dangerIndices = new Set<number>();
    hazards.forEach((h) => {
      const start = Math.max(0, h.segmentIndex - 20);
      const end = Math.min(path.length - 1, h.segmentIndex + 20);
      for (let i = start; i <= end; i++) dangerIndices.add(i);
    });

    // Draw main cyan route
    routeLineRef.current = new window.google.maps.Polyline({
      path: fullPath,
      geodesic: true,
      strokeColor: '#22d3ee',
      strokeOpacity: 0.8,
      strokeWeight: 4,
      map,
    });

    // Draw danger segments in crimson
    for (let i = 1; i < path.length; i++) {
      if (dangerIndices.has(i)) {
        const seg = new window.google.maps.Polyline({
          path: [
            new window.google.maps.LatLng(path[i - 1].lat, path[i - 1].lng),
            new window.google.maps.LatLng(path[i].lat, path[i].lng),
          ],
          strokeColor: '#ef4444',
          strokeOpacity: 1,
          strokeWeight: 6,
          map,
          icons: [{ icon: { path: 'M 0,-1 0,1', strokeOpacity: 1, strokeWeight: 2, strokeColor: '#ef4444' }, offset: '0', repeat: '10px' }],
        });
        dangerPolylineRefs.current.push(seg);
      }
    }

    // Hazard markers
    hazards.forEach((h) => {
      const marker = new window.google.maps.Marker({
        position: new window.google.maps.LatLng(h.incident.coordinates.lat, h.incident.coordinates.lng),
        map,
        icon: {
          path: window.google.maps.SymbolPath.CIRCLE,
          scale: 8,
          fillColor: '#ef4444',
          fillOpacity: 0.9,
          strokeColor: '#ef4444',
          strokeWeight: 2,
        },
        title: `${h.incident.id} — ${h.incident.title} (${h.distanceKm}km from route)`,
      });
      hazardMarkersRef.current.push(marker);
    });

    // Fit bounds
    const bounds = new window.google.maps.LatLngBounds();
    fullPath.forEach((p) => bounds.extend(p));
    map.fitBounds(bounds, { top: 50, right: 350, bottom: 50, left: 50 });
  };

  // Build interpolated straight-line path (every ~5km)
  const buildStraightPath = (from: Coordinate, to: Coordinate): { lat: number; lng: number }[] => {
    const totalDist = haversineDistance(from.lat, from.lng, to.lat, to.lng);
    const steps = Math.max(2, Math.ceil(totalDist / 5));
    const path: { lat: number; lng: number }[] = [];
    for (let i = 0; i <= steps; i++) {
      const t = i / steps;
      path.push({ lat: from.lat + (to.lat - from.lat) * t, lng: from.lng + (to.lng - from.lng) * t });
    }
    return path;
  };

  const calculateRoute = useCallback(() => {
    if (!map || !originCoords || !destinationCoords) return;
    setCalculating(true);

    // Clean previous route
    if (routeLineRef.current) routeLineRef.current.setMap(null);
    hazardMarkersRef.current.forEach((m) => m.setMap(null));
    dangerPolylineRefs.current.forEach((p) => p.setMap(null));
    hazardMarkersRef.current = [];
    dangerPolylineRefs.current = [];

    const directionsService = new window.google.maps.DirectionsService();

    directionsService.route(
      {
        origin: new window.google.maps.LatLng(originCoords.lat, originCoords.lng),
        destination: new window.google.maps.LatLng(destinationCoords.lat, destinationCoords.lng),
        travelMode: window.google.maps.TravelMode.DRIVING,
      },
      (result: any, status: string) => {
        if (status !== 'OK' || !result.routes.length) {
          // Fallback: straight-line route with Haversine distance
          const straightPath = buildStraightPath(originCoords, destinationCoords);
          const distKm = haversineDistance(originCoords.lat, originCoords.lng, destinationCoords.lat, destinationCoords.lng);
          const durationMin = Math.round((distKm / 65) * 60); // ~65 km/h avg speed
          const hazards = findHazards(straightPath);
          drawRoute(straightPath, hazards);
          const hours = Math.floor(durationMin / 60);
          const mins = durationMin % 60;
          setRouteResult({
            distance: `${Math.round(distKm)} km (straight-line)`,
            distanceKm: Math.round(distKm),
            duration: hours > 0 ? `${hours}h ${mins}m (est.)` : `${mins}m (est.)`,
            durationMinutes: durationMin,
            path: straightPath,
            hazards,
          });
          setCalculating(false);
          return;
        }

        const route = result.routes[0];
        const leg = route.legs[0];
        const path: { lat: number; lng: number }[] = [];

        route.legs.forEach((l: any) => {
          l.steps.forEach((step: any) => {
            step.path.forEach((p: any) => {
              path.push({ lat: p.lat(), lng: p.lng() });
            });
          });
        });

        const distanceKm = leg.distance.value / 1000;
        const durationMinutes = Math.round(leg.duration.value / 60);
        const hazards = findHazards(path);
        drawRoute(path, hazards);

        const hours = Math.floor(durationMinutes / 60);
        const mins = durationMinutes % 60;

        setRouteResult({
          distance: `${Math.round(distanceKm)} km`,
          distanceKm: Math.round(distanceKm),
          duration: hours > 0 ? `${hours}h ${mins}m` : `${mins}m`,
          durationMinutes,
          path,
          hazards,
        });
        setCalculating(false);
      }
    );
  }, [map, originCoords, destinationCoords]);

  const clearRoute = useCallback(() => {
    if (routeLineRef.current) { routeLineRef.current.setMap(null); routeLineRef.current = null; }
    hazardMarkersRef.current.forEach((m) => m.setMap(null));
    hazardMarkersRef.current = [];
    dangerPolylineRefs.current.forEach((p) => p.setMap(null));
    dangerPolylineRefs.current = [];
    setRouteResult(null);
    setOriginCoords(null);
    setDestinationCoords(null);
    setOrigin('');
    setDestination('');
  }, []);

  return (
    <motion.div
      initial={{ x: -400, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      exit={{ x: -400, opacity: 0 }}
      transition={{ type: 'spring', damping: 25, stiffness: 200 }}
      className="absolute top-4 left-4 z-30 w-[340px] max-h-[calc(100vh-120px)] overflow-y-auto rounded-2xl bg-slate-950/90 backdrop-blur-xl border border-cyan-500/20 shadow-2xl shadow-cyan-500/10"
    >
      {/* Header */}
      <div className="px-4 py-3 border-b border-white/5 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-cyan-500/15 flex items-center justify-center">
            <Navigation size={16} className="text-cyan-400" />
          </div>
          <div>
            <h3 className="text-xs font-bold text-white tracking-wide">Emergency Route & Hazard Inspector</h3>
            <p className="text-[9px] text-slate-500">A-to-B tactical navigation</p>
          </div>
        </div>
        <div className="flex items-center gap-1">
          <button onClick={() => setExpanded(!expanded)} className="p-1 text-slate-400 hover:text-white transition-colors rounded">
            {expanded ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
          </button>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-white transition-colors rounded">
            <X size={14} />
          </button>
        </div>
      </div>

      {expanded && (
        <div className="p-4 space-y-3">
          {/* Point A */}
          <div>
            <label className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5 mb-1.5">
              <div className="w-2 h-2 rounded-full bg-cyan-400" />
              Point A — Origin / Base Station
            </label>
            <div className="relative">
              <input
                type="text"
                value={origin}
                onChange={(e) => { setOrigin(e.target.value); setOriginCoords(null); }}
                onFocus={() => setShowPresets('origin')}
                placeholder="Select or type origin..."
                className="w-full bg-slate-800/60 border border-white/10 rounded-lg px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500/50 transition-colors"
              />
              <button onClick={() => setShowPresets(showPresets === 'origin' ? null : 'origin')} className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400">
                <ChevronDown size={14} />
              </button>
              {showPresets === 'origin' && (
                <div className="absolute top-full left-0 right-0 mt-1 bg-slate-800 border border-white/10 rounded-lg overflow-hidden z-10 shadow-xl max-h-48 overflow-y-auto">
                  {PRESET_LOCATIONS.map((loc) => (
                    <button
                      key={loc.label}
                      onClick={() => selectPreset(loc, 'origin')}
                      className="w-full text-left px-3 py-2 text-xs text-slate-300 hover:bg-cyan-500/10 hover:text-white transition-colors flex items-center gap-2"
                    >
                      <MapPin size={12} className="text-cyan-400 shrink-0" />
                      {loc.label}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Point B */}
          <div>
            <label className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5 mb-1.5">
              <div className="w-2 h-2 rounded-full bg-red-400" />
              Point B — Destination / Target Area
            </label>
            <div className="relative">
              <input
                type="text"
                value={destination}
                onChange={(e) => { setDestination(e.target.value); setDestinationCoords(null); }}
                onFocus={() => setShowPresets('dest')}
                placeholder="Select or type destination..."
                className="w-full bg-slate-800/60 border border-white/10 rounded-lg px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-red-500/50 transition-colors"
              />
              <button onClick={() => setShowPresets(showPresets === 'dest' ? null : 'dest')} className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400">
                <ChevronDown size={14} />
              </button>
              {showPresets === 'dest' && (
                <div className="absolute top-full left-0 right-0 mt-1 bg-slate-800 border border-white/10 rounded-lg overflow-hidden z-10 shadow-xl max-h-48 overflow-y-auto">
                  {PRESET_LOCATIONS.map((loc) => (
                    <button
                      key={loc.label}
                      onClick={() => selectPreset(loc, 'dest')}
                      className="w-full text-left px-3 py-2 text-xs text-slate-300 hover:bg-red-500/10 hover:text-white transition-colors flex items-center gap-2"
                    >
                      <MapPin size={12} className="text-red-400 shrink-0" />
                      {loc.label}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Calculate Button */}
          <button
            onClick={calculateRoute}
            disabled={!originCoords || !destinationCoords || calculating}
            className="w-full py-2.5 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-2 disabled:opacity-40 disabled:cursor-not-allowed bg-gradient-to-r from-cyan-600 to-cyan-500 hover:from-cyan-700 hover:to-cyan-600 text-white shadow-lg shadow-cyan-500/20"
          >
            {calculating ? (
              <>
                <div className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Calculating...
              </>
            ) : (
              <>
                <Zap size={14} />
                Calculate Tactical Route
              </>
            )}
          </button>

          {/* Route Results */}
          <AnimatePresence>
            {routeResult && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="overflow-hidden"
              >
                {/* Stats Row */}
                <div className="grid grid-cols-2 gap-2 mb-3">
                  <div className="bg-slate-800/60 rounded-lg p-2.5 border border-cyan-500/10">
                    <div className="flex items-center gap-1.5 mb-1">
                      <Ruler size={12} className="text-cyan-400" />
                      <span className="text-[9px] font-semibold text-slate-400 uppercase">Distance</span>
                    </div>
                    <div className="text-lg font-black text-cyan-400">{routeResult.distance}</div>
                  </div>
                  <div className="bg-slate-800/60 rounded-lg p-2.5 border border-blue-500/10">
                    <div className="flex items-center gap-1.5 mb-1">
                      <Clock size={12} className="text-blue-400" />
                      <span className="text-[9px] font-semibold text-slate-400 uppercase">ETA</span>
                    </div>
                    <div className="text-lg font-black text-blue-400">{routeResult.duration}</div>
                  </div>
                </div>

                {/* Hazard Detection */}
                <div className={`rounded-lg p-3 border ${
                  routeResult.hazards.length > 0
                    ? 'bg-red-500/10 border-red-500/30'
                    : 'bg-emerald-500/10 border-emerald-500/30'
                }`}>
                  <div className="flex items-center gap-2 mb-2">
                    <AlertTriangle size={14} className={routeResult.hazards.length > 0 ? 'text-red-400' : 'text-emerald-400'} />
                    <span className="text-[10px] font-bold uppercase tracking-wider text-white">
                      Active Hazards Along Route
                    </span>
                  </div>

                  {routeResult.hazards.length > 0 ? (
                    <>
                      <div className="text-sm font-black text-red-400 mb-2">
                        ⚠️ {routeResult.hazards.length} Active {routeResult.hazards.length === 1 ? 'Hazard' : 'Hazards'} Detected
                      </div>
                      <div className="space-y-1.5 max-h-40 overflow-y-auto">
                        {routeResult.hazards.map((h) => (
                          <div key={h.incident.id} className="flex items-center gap-2 bg-red-500/10 rounded-md px-2 py-1.5">
                            <span className="text-xs">
                              {h.incident.type === 'flood' ? '🌊' : h.incident.type === 'fire' ? '🔥' : h.incident.type === 'earthquake' ? '🌍' : h.incident.type === 'landslide' ? '⛰️' : '🌪️'}
                            </span>
                            <div className="flex-1 min-w-0">
                              <div className="text-[10px] font-bold text-white truncate">{h.incident.id}</div>
                              <div className="text-[9px] text-slate-400 truncate">{h.incident.title}</div>
                            </div>
                            <div className="text-right shrink-0">
                              <div className="text-[10px] font-bold text-red-400">{h.distanceKm}km</div>
                              <div className="text-[8px] text-slate-500">from route</div>
                            </div>
                          </div>
                        ))}
                      </div>
                      <div className="mt-2 text-[9px] text-red-300/70">
                        🔴 Route segments near hazards highlighted in crimson
                      </div>
                    </>
                  ) : (
                    <div className="text-xs text-emerald-300">
                      ✅ Route clear — no active incidents within 10km corridor
                    </div>
                  )}
                </div>

                {/* Clear Route */}
                <button
                  onClick={clearRoute}
                  className="w-full mt-2 py-2 rounded-lg bg-slate-800/60 border border-white/5 text-xs text-slate-400 hover:text-white hover:bg-slate-700/60 transition-all"
                >
                  Clear Route
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      )}
    </motion.div>
  );
}
